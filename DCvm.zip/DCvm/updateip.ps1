NET STOP WazuhSvc

$oldip= Get-Content -path 'ip.txt' -raw

$newip= Read-Host "Please enter current SIEM external IP"

(Get-Content -path "C:\Program Files (x86)\ossec-agent\ossec.conf") -replace $oldip,$newip| Set-Content -Path "C:\Program Files (x86)\ossec-agent\ossec.conf"

NET START WazuhSvc

Set-Content -Path "ip.txt" -value $newip