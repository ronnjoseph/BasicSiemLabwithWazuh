#Inside DCvm
# Installing VM services

Get-WindowsFeature
Get-Windowsfeature | ? {$_.Name -LIKE "ad*"}
Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools
Import-Module ADDSDeployment
$Password = (ConvertTo-SecureString -String "P@ss1w0rd" -AsPlainText -Force)
$DomainName= "Jewels.local"
Install-ADDSForest -DomainName $DomainName -InstallDNS -SafeModeAdministratorPassword $Password -Confirm -Force

# wait until we can access the AD. this is needed to prevent errors like:
#   Unable to find a default server with Active Directory Web Services running.


#Rename computer
#$Cred = New-Object System.Management.Automation.PSCredential ("Jewels\Admin", $Password)
#Rename-Computer -NewName "DiamondDC" -DomainCredential $Cred -Restart

#End of DCvm


