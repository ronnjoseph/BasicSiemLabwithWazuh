#Set-DnsClientServerAddress -interfacealias "Ethernet 2" -serveraddresses ("10.0.1.10")
$Password = (ConvertTo-SecureString -String "P@ss1w0rd" -AsPlainText -Force)
$Cred = New-Object System.Management.Automation.PSCredential ("Jewels\Admin", $Password)
add-computer -domainname Jewels -credential $Cred -restart -force

