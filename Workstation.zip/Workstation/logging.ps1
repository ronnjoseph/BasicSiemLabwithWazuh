#Sysmon Installation
Invoke-WebRequest -Uri https://download.sysinternals.com/files/Sysmon.zip -Outfile Sysmon.zip
Expand-Archive Sysmon.zip
Invoke-WebRequest -Uri https://raw.githubusercontent.com/SwiftOnSecurity/sysmon-config/master/sysmonconfig-export.xml -Outfile sysmonconfig-export.xml
.\Sysmon\sysmon64.exe -accepteula -i sysmonconfig-export.xml



#Audit Policies for logging 
auditpol /set /category:"Account Logon" /failure:enable /success:enable
auditpol /set /category:"Account Management" /failure:enable /success:enable
auditpol /set /subcategory:"Application Group Management" /failure:disable /success:disable
auditpol /set /subcategory:"Distribution Group Management" /failure:disable /success:disable
auditpol /set /subcategory:"Process Creation" /failure:enable /success:enable
auditpol /set /subcategory:"DPAPI Activity" /failure:enable /success:enable
auditpol /set /subcategory:"Directory Service Access" /failure:enable /success:enable
auditpol /set /subcategory:"Directory Service Changes" /failure:enable /success:enable
auditpol /set /subcategory:"Other Logon/Logoff Events" /failure:enable /success:enable
auditpol /set /subcategory:"Special Logon" /failure:enable /success:enable
auditpol /set /subcategory:"Audit Policy Change" /failure:enable
auditpol /set /subcategory:"Authentication Policy Change" /failure:enable
auditpol /set /subcategory:"Security System Extension" /failure:enable /success:enable
gpupdate /force

Start-Sleep 3

$externalip = '**********************'
Invoke-WebRequest -Uri https://packages.wazuh.com/4.x/windows/wazuh-agent-4.3.5-1.msi -OutFile ${env:tmp}\wazuh-agent-4.3.5.msi; msiexec.exe /i ${env:tmp}\wazuh-agent-4.3.5.msi /q WAZUH_MANAGER=$externalip WAZUH_REGISTRATION_SERVER=$externalip 
#no spaces between = and ip

$externalip | Out-File -Filepath ip.txt

Start-Sleep 5

#Sysmon insert
$cont = "  <localfile>`n    <location>Microsoft-Windows-Sysmon/Operational</location>`n    <log_format>eventchannel</log_format>`n  </localfile>`n"

$filecontent = Get-Content -path "C:\Program Files (x86)\ossec-agent\ossec.conf"
$fileContent[47-1] += $cont
$fileContent | Set-Content -path "C:\Program Files (x86)\ossec-agent\ossec.conf"

#Defenderlogs insert
$cont2 = "  <localfile>`n    <location>Microsoft-Windows-Windows Defender/Operational</location>`n    <log_format>eventchannel</log_format>`n  </localfile>`n"

$filecontent = Get-Content -path "C:\Program Files (x86)\ossec-agent\ossec.conf"
$fileContent[51-1] += $cont2
$fileContent | Set-Content -path "C:\Program Files (x86)\ossec-agent\ossec.conf"

#Installing PS7
Invoke-WebRequest -Uri https://github.com/PowerShell/PowerShell/releases/download/v7.2.5/PowerShell-7.2.5-win-x64.msi -Outfile "C:\Users\vagrant\ps7.msi"
.\ps7.msi /quiet
#Insert domainstats configs
Invoke-WebRequest -Uri https://raw.githubusercontent.com/juaromu/wazuh-domain-stats-alienvault/main/otx.ps1 -Outfile "C:\Users\vagrant\otx.ps1"
$otxkey = "7ef6d8658ee93018d13ecf1ec8e5a951c6e1d0364a0868efbec994635ebb7270"
(Get-Content -path "C:\Users\vagrant\otx.ps1") -replace "Your_API_KEY", $otxkey | Set-Content -Path "C:\Users\vagrant\otx.ps1"

Set-Content -Path "C:\Program Files (x86)\ossec-agent\active-response\bin\otx.cmd" -Value ":: Simple script to run AlienVault OTX PShell script.`n:: The script executes a powershell script and appends output.`n@ECHO OFF`nECHO.`n`n'C:\Program Files\PowerShell\7\'pwsh.exe -executionpolicy ByPass -File 'C:\Users\vagrant\otx.ps1'`n`n:Exit"

NET START WazuhSvc

