curl -so wazuh-agent-4.3.5.deb https://packages.wazuh.com/4.x/apt/pool/main/w/wazuh-agent/wazuh-agent_4.3.5-1_amd64.deb && sudo WAZUH_MANAGER='34.173.77.117' dpkg -i ./wazuh-agent-4.3.5.deb

sudo systemctl daemon-reload
sudo systemctl enable wazuh-agent
sudo systemctl start wazuh-agent

echo "*.* @@34.133.4.23:514" >> /etc/rsyslog.conf
systemctl start rsyslog
