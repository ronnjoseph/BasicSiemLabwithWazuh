curl -so wazuh-agent-4.3.5.deb https://packages.wazuh.com/4.x/apt/pool/main/w/wazuh-agent/wazuh-agent_4.3.5-1_amd64.deb && sudo WAZUH_MANAGER='34.173.77.117' dpkg -i ./wazuh-agent-4.3.5.deb

sudo systemctl daemon-reload
sudo systemctl enable wazuh-agent
sudo systemctl start wazuh-agent


printf 'P@ss1w0rd\nP@ss1w0rd\n' | sudo passwd
printf 'P@ss1w0rd\n' | su -
wget https://downloads.ipfire.org/releases/ipfire-2.x/2.27-core169/ipfire-2.27.x86_64-full-core169.iso
mkdir -p /mnt/disk
mount -o loop ipfire-2.27.x86_64-full-core169.iso /mnt/disk
mount
ls -l /mnt/disk/
cd /mnt/disk/
ls -l
cp file1 file2 /home/vivek/Downloads