#! /bin/bash

# printf 'P@ss1w0rd\nP@ss1w0rd\n' | sudo passwd
# printf 'P@ss1w0rd\n' | su -
# sudo apt update -y
# sudo apt upgrade -y

#Indexer
curl -sO https://packages.wazuh.com/4.3/wazuh-install.sh
curl -sO https://packages.wazuh.com/4.3/config.yml
sed -i 's/<indexer-node-ip>/0.0.0.0/g' config.yml
sed -i 's/<wazuh-manager-ip>/0.0.0.0/g' config.yml
sed -i 's/<dashboard-node-ip>/0.0.0.0/g' config.yml
sudo bash wazuh-install.sh --generate-config-files
curl -sO https://packages.wazuh.com/4.3/wazuh-install.sh
sudo bash wazuh-install.sh --wazuh-indexer node-1
sudo bash wazuh-install.sh --start-cluster
#Server
curl -sO https://packages.wazuh.com/4.3/wazuh-install.sh
sudo bash wazuh-install.sh --wazuh-server wazuh-1
#Dashboard
curl -sO https://packages.wazuh.com/4.3/wazuh-install.sh
sudo bash wazuh-install.sh --wazuh-dashboard dashboard
sudo tar -O -xvf wazuh-install-files.tar wazuh-install-files/wazuh-passwords.txt


cd /var/ossec/ruleset/rules/
wget https://raw.githubusercontent.com/OpenSecureCo/Wazuh/main/sysmon.xml
wget https://raw.githubusercontent.com/juaromu/wazuh-domain-stats-alienvault/main/dns_stats.xml

systemctl restart wazuh-manager

#DOMAIN_STATS Server install
apt-get install python3-pip -y
git clone https://github.com/markbaggett/domain_stats
cd domain_stats
python3 -m pip install .

mkdir /mydata
printf '0.0.0.0\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nY\n' | domain-stats-settings /mydata 
printf 'P@ss1w0rd\nP@ss1w0rd\n' | sudo passwd

printf 'P@ss1w0rd\n' | su -
cd /var/ossec/integrations/

wget https://raw.githubusercontent.com/juaromu/wazuh-domain-stats-alienvault/main/custom-dnsstats

wget https://raw.githubusercontent.com/juaromu/wazuh-domain-stats-alienvault/main/custom-dnsstats.py
sed -i 's/127.0.0.1/0.0.0.0/g' custom-dnsstats.py
sudo apt install chwon -y
chwon root:ossec custom-dnsstats*
chmod 750 custom-dnsstats*

echo "<ossec_config>
	<!-- DNS Hunt Integration -->
	<integration>
	 <name>custom-dnsstats</name>
	 <rule_id>101100</rule_id>
	 <alert_format>json</alert_format>
	</integration>
</ossec_config>" >> /var/ossec/etc/ossec.conf

echo "<ossec_config>
<command>
    <name>alienvault_otx</name>
    <executable>otx.cmd</executable>
    <timeout_allowed>no</timeout_allowed>
  </command>
 <active-response>
   <disabled>no</disabled>
   <level>3</level>
   <command>alienvault_otx</command>
   <location>local</location>
   <rules_group>dnsstat_alert</rules_group>
  </active-response>
</ossec_config>" >> /var/ossec/etc/ossec.conf


# echo "<ossec_config>
#   <remote>
#    <connection>syslog</connection>
#    <port>514</port>
#    <protocol>udp</protocol>
#    <allowed-ips>10.0.2.0/24</allowed-ips>
#    <local_ip>0.0.0.0</local_ip>
#   </remote>
# </ossec_config>" >> /var/ossec/etc/ossec.conf

echo "<ossec_config>
  <localfile>
    <log_format>syslog</log_format>
    <location>/var/log/suricata/eve.json</location>
  </localfile>
</ossec_config>" >> /var/ossec/etc/ossec.conf


systemctl restart wazuh-manager



#######VEloraptor
wget https://github.com/Velocidex/velociraptor/releases/download/v0.6.5-0/velociraptor-v0.6.5-2-linux-amd64
chmod +x velociraptor-v0.6.5-2-linux-amd64
printf '\n\n\n' | sleep 3 | printf '\n\n\n\nadminip\n01P@ss1w0rd10\n\n\n\n\n' | ./velociraptor-v0.6.5-2-linux-amd64 config generate -i

./velociraptor-v0.6.5-2-linux-amd64 --config server.config.yaml debian server --binary velociraptor-v0.6.5-2-linux-amd64
dpkg -i velociraptor_0.6.4-2_server.deb
systemctl status velociraptor_server

